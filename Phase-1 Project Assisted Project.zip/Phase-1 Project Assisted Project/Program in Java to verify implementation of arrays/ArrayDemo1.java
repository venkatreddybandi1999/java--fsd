package array;
import java.util.Scanner;

public class ArrayDemo1 {

	public static void main(String[] args) {
		
		int array[]=new int[5];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<array.length;i++)
		{
			System.out.println("Enter any number");
			array[i]=sc.nextInt();
		}
		System.out.println("Lets print elements  of array");
		
for (int a:array) {
	System.out.print(a+"\t");
}
	}

}
