package string;

public class StringBuilderDemo {

	public static void main(String[] args) {
		// Creating a string
		String str= new String("Hello world");
		
		//converting to string builder
		StringBuilder s = new StringBuilder (str);
		System.out.println(s);
		
		// to know the length of string
				System.out.println("Size:"+s.length());
				
				// to Add something to string
				System.out.println(s.append("java"));
				
				// To insert at Particular index
				s.insert(11, " ");
				System.out.println(s);
				s.replace(12,15, "bye");
				System.out.println(s);
				s.reverse();
				System.out.println(s);
				
				
		

	}

}
