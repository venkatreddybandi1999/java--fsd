package string;

public class StringBufferDemo {

	public static void main(String[] args) {
		String str="Hello World";
		
		System.out.println(str);
		
		//converting string to string buffer
		StringBuffer s= new StringBuffer(str);
		System.out.println(s);
		
		//to get at particular index
        char c=s.charAt(2);
		
		System.out.println(c);
		
		// to know the length of string
		System.out.println("Size:"+s.length());
		
		// to Add something to string
		System.out.println(s.append("java"));
		
		// To insert at Particular index
		s.insert(11, " ");
		System.out.println(s);
		s.replace(12,15, "bye");
		System.out.println(s);
		s.reverse();
		System.out.println(s);
		
		;
		

	}

}
