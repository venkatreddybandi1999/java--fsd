package queue;

import java.util.*;

public class QueueExample {
	public static void main(String[] args) {
		Queue <String> Queue= new LinkedList<String>();
		
		Queue.add("India");
		Queue.add("China");
		Queue.add("Japan");
		Queue.add("Russia");
		Queue.add("Indonesia");
		Queue.add("US");
		
		System.out.println("Queue is : "+Queue);
		
		
		//find head of queue
		System.out.println("Head of Queue: "+Queue.peek());
		
		//To find the size of Queue
		System.out.println("Size of Queue :"+Queue.size());
		
		//To remove an particular element
		Queue.remove("China");
		System.out.println("After removing China:"+Queue);
		
		//TO add an new element into an existing queue
		Queue.add("USA");
		System.out.println("After adding USA:"+Queue);
		//Using only remove we can remove head
		Queue.remove();
				
		System.out.println("After Removing Head: "+Queue);
				
		
	}

}
