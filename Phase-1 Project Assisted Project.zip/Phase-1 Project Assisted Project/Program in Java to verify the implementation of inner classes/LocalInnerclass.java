package innerClass;

public class LocalInnerclass {

void Check(String locker_key) {
		
		
		if(locker_key.equals("nikunj@gmail.com")) {
			
			class Inner {
				
				
				void validate() {
					System.out.println("User Found and Authenticated");
				}
				
				
			}
			
			Inner inner= new Inner();
			inner.validate();


		}
		else {
			
			System.out.println("Not Valid");
		}
		
		
	}
	
	
	public static void main(String[] args) {
		
		LocalInnerclass outer= new LocalInnerclass();
		outer.Check("nikunj@gmail.com");
		
		
	}
}
