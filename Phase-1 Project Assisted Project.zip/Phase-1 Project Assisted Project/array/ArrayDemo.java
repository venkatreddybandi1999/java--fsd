package array;

public class ArrayDemo {
	public static void main(String[] args) {
		
		int array[]= {12,13,14,15,16};
		System.out.println("Element at index3:"+array[3]);
		System.out.println("Length of an Array"+array.length);
		System.out.println("Acces using for loop");
		for(int i=0;i<array.length;i++) {
			System.out.println(array[i]);
		}
		System.out.println();
		
		
		for( int a:array){
			System.out.print(a+" ");
		}
		
		
	}

}
