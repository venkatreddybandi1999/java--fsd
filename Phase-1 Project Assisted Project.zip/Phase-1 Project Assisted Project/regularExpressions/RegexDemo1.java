package regularExpressions;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class RegexDemo1 {

	
	//Matching the input with given gegex values
	public static void main(String[] args) {
		String regex="[A-za-z]+";
		String input="RegularExpressions";
		
		Pattern p=Pattern.compile(regex);
		Matcher m=p.matcher(input);
		
		if(m.matches()) {
			System.out.println("It matches");
			
		}
		else {
			System.out.println("not matches");
		}
		

	}

}
