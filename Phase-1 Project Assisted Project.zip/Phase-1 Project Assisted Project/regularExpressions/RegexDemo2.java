package regularExpressions;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class RegexDemo2 {

	
	//Finding which Regex values are matching or printing the matching values
	public static void main(String[] args) {
		String regex="[a-z]+";
		String input="Regular Expressions2";
		
		Pattern p=Pattern.compile(regex);
		Matcher m=p.matcher(input);
		
		while (m.find()) {
			System.out.println(input.substring(m.start(),m.end()));
			
		}

	}

}
