package diamondProblem;

public interface Second {
	public default  void show() {
		System.out.println("This is my second interface");
	}
}
