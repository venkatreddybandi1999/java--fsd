package collections;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Collections;

public class ArrayListDemo {
	public static void main(String[] args) {
	
	ArrayList<Integer> list= new ArrayList<Integer>();
	
	list.add(0);
	list.add(1);
	list.add(2);
	list.add(3);
	list.add(3);
	
	//to print list
	 System.out.println(list);
	 
	 //size of list
	 System.out.println(list.size());
	 // get elements at particular index
	 int element=list.get(1);
	 System.out.println("Element at zero index is :"+list.get(2));
	 
	 //To add element to  the list
	 list.add(4);
	 System.out.println(list);
	 //To add element at particulat index
	 list.add(1,7);
	 System.out.println(list);
	 
	 //To set element from the existing list
	 list.set(0, 6);
	 System.out.println(list);
	  //remove with index number
	 list.remove(4);
	 System.out.println(list);
	 
	 System.out.println(list.size());
	 
	// using for loop
	 for(Integer s:list) {
			System.out.println("Using For Loop: "+s);
	
	 }
	 for ( int  i=0;i<list.size();i++) {
		System.out.print(list.get(i));
		 
	 }
	 //System.out.println();
	 
	 //sorting
	
	 
	 //using iterator
	 Iterator iterator=list.iterator();
	 while(iterator.hasNext()) {
		 System.out.println(iterator.next());
	 }
	}
}
