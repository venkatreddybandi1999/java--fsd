package collections;
import java.util.LinkedHashSet;
import java.util.Iterator;

public class LinkedHashSetDemo {

	public static void main(String[] args) {
		
		//linked hashset is an ordered version of hashset
		//whenever iteration order is needed to be maintained this class is used
		//while iterating elements are fetched as per they were inserted
		//do not allows duplicate values
		LinkedHashSet <String>  linked= new LinkedHashSet<String>();
		linked.add("A");
		linked.add("B");
		linked.add("C");
		linked.add("D");
		
		//note: do not allows duplicate values, so 'A' will not be added but 'E' will be added
		linked.add("A");
		linked.add("E");
		linked.add(null);
		System.out.println(linked);
		
		
		//to get size
		System.out.println(linked.size());
		System.out.println("Contains E: "+linked.contains("E"));
		
		linked.remove(null);
		
		System.out.println("After Remove: "+linked);
		
		//Using iterator
		Iterator iterator=linked.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		

	}

}
