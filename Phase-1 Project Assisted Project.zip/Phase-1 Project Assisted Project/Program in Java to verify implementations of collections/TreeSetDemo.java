package collections;
import java.util.TreeSet;
import java.util.Iterator;
public class TreeSetDemo {

	public static void main(String[] args) {
		
			//tree set is one of the most imp implementation of sorted set interface in java
			// the order of the element is maintained by the set using their natural ordering
			// null is not allowed in treeset
			TreeSet<String> set = new TreeSet<String>(); 
			
			set.add("Banana");
			set.add("Cherry");
			set.add("Almond");
			set.add("Apple");
			//set.add(null);
			
			System.out.println(set);
			
			System.out.println("Size: "+set.size());
			
			System.out.println("Contains: "+ set.contains("Banana"));
			
			
			//Iterator
			Iterator iterator=set.iterator();
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
			}

	}

}
