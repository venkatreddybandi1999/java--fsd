package map;

import java.util.HashMap;

public class HashMapsdemo {
	public static void main(String[] args) {
		//Hashmap is implementation of map.
		//it inherits hashmap class
		//it maintains insertion order
		//methods:put,get,remove,getkey
		//duplicate key values are not allowed
		
		HashMap<Integer,String> map= new HashMap<Integer,String>();
		
		map.put(1,  "abc");
		map.put(2, "dilip");
		map.put(3, "Alex");
		map.put(4, "null");// key is not null value is null
		map.put(null, "red"); // key is null value is not null 
		map.put(null, "null");// you can't add both null-you can add only one null key in map
		map.put(6, "null");
		map.put(5,"nikunj");
		
		System.out.println(map);
		System.out.println("To get element at 1:" +map.get(1));
		System.out.println("To get element at 2:" +map.get(2));
		System.out.println("To get element at 3:" +map.get(3));
		System.out.println("To get element at 4:" +map.get(4));
		System.out.println("To get element at null:" +map.get(null));
		System.out.println("To get element at 6:" +map.get(6));
		
		
		
		
	}

}
