package map;

import java.util.TreeMap;

public class TreeMapDemo {

	public static void main(String[] args) {
		
		TreeMap<Integer, String> map= new TreeMap<Integer, String>();
	
		//null key is not accepted in treemap but null value can be accepted
		//treemap is implementation of map and sorted map
		
		map.put(1,  "abc");
		map.put(2, "dilip");
		map.put(3, "Alex");
		map.put(4, "null");// key is not null value is null
        //map.put(null, "Alex"); // null key  is not allowed
		//map.put(null, "null");// null value is not allowed
		System.out.println(map);
		System.out.println("To get element at 1:" +map.get(1));
		System.out.println("To get element at 2:" +map.get(2));
		System.out.println("To get element at 3:" +map.get(3));
		System.out.println("To get element at 4:" +map.get(4));
		//System.out.println("To get element at null:" +map.get(null));
		System.out.println("To get element at 6:" +map.get(6));
		

	}

}
