package inheritance;

public class inheritanceTest {
	//inheritance in java  help for code  reusability
		//moreover we can prepare new methods which are  not available in parent class also
		
		// 
		public static void main(String[] args) {
			
			MountainBike mb=  new MountainBike(25, 100, 20);
			System.out.println("Details: "+mb);

		}
}
