package encapsulation;

public class testStudent {
	public static void main(String[] args) {
		student s1=new student();
		s1.setId(1);
		s1.setName("Venky");
		s1.setEmail("venky@gmail.com");
		s1.setMobile("999999999");
		System.out.println("Id:"+s1.getId()+"\nName:"+s1.getName()+"\nEmail:"+s1.getEmail()+"\nMobile:"+s1.getMobile());

		
		//employee class with string method
		
		Employee e1= new Employee();
		e1.setId(1);
		e1.setName("Nikunj");
		e1.setEmail("nikunj@gmail.com");
		e1.setPassword("12345");
		e1.setMobile("9876543210");
		
		
		System.out.println(e1);
	}
}
