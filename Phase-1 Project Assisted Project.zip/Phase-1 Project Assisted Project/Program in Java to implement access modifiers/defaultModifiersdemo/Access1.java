package defaultModifiersdemo;

public class Access1 {
	// default class
	String fname="xyz";
    String lname="abc";
    String mail="xyz@mail.com";
    int age=23;
    public static void main(String[] args) {
    	
    }
	
}



	
	

	


