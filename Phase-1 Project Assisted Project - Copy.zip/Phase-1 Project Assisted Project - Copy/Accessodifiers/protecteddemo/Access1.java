package protecteddemo;

public class Access1 {
	 
	protected String fname="xyz";
	protected String lname="abc";
	protected int age=20;
	public static void main (String[] args) {
		
	}
	
}
//creating another class that extends class access1
class Access2 extends Access1 {
	//we can use all i.e public, private,protected,default
	private int yob=2005;
	public static void main (String[] args) {
		Access2 obj= new Access2();
		System.out.println("Name:"+obj.fname+""+obj.lname);
		System.out.println("Age:"+obj.age);
		System.out.println("YOB:"+obj.yob);
		
		
	}
	
}