package privatedemo;

public class Access1 {

	//private class
	//it is visible in the declared class
	private String fname="xyz";
	private int age=25;
	public static void main(String[] args) {
		
		Access1 obj=new Access1();
		System.out.println(obj.fname);
		System.out.println(obj.age);
		
		
	}
	
	
}
