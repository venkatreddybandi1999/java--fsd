package privatedemo;

public class Access2 {
// it is not visible in another package
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Access1 obj=new Access1();
		System.out.println(obj.fname);
		System.out.println(obj.age);
		
		
	}
	

	}


