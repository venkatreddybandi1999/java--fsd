package collections;
import java.util.LinkedList;
import java.util.Iterator;
public class LinkedListDemo {

	public static void main(String[] args) {
		
		LinkedList <Integer> list= new LinkedList<Integer>();
		//linked list is a part of the collection framework present in jav.utilpackage
		//it is linear datastructure where elements are not stored in contiguous memory location
		//every element is sepaaet object with datapart and address
		//this elements are linked using pointer and addresss
		// each ealement is called node
		//due to dynamicallay insertion and deleteion they are much more preffered than arrays

		list.add(0);
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(3);
		list.add(4);
		list.add(null);
		System.out.println(list);
		
		
		System.out.println(list.size());
		list.remove(4);
		System.out.println(list);
		list.add(5);
		System.out.println(list);
		list.set(0, 5);
		System.out.println(list);
		
		//To get the first value and it is not applicable for Arraylist
		System.out.println(list.getFirst());
		
		//To get the type of class we used
		System.out.println(list.getClass());
		
		//To get the last value
		System.out.println(list.getLast());
		
		
		//Using for loop
		for (Integer s:list) {
			System.out.println("using for loop:"+s);
		
		}
		Iterator iterator=list.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}

	}

}
