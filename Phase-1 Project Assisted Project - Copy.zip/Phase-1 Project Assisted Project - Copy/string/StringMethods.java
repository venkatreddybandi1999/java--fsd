package string;

public class StringMethods {
	public static void main(String[] args) {
		
		String s= new String ("Hello java");
		
		char c =s.charAt(3);
		System.out.println(c);
		//length of String
		System.out.println("Length of String:"+s.length());
		// To upper case
		// upper casse
		System.out.println(s.toUpperCase());
		//lowercase
		System.out.println(s.toLowerCase());
		//To check the word 
		System.out.println("to check the given word contains or not: java or not"+" " +s.contains("java"));
		//substring
		System.out.println("Substrings between 2 and 5:"+s.substring(3, 7));
		
		String result[]=s.split("");
		for(String s1:result) {
			System.out.print(s1);
			System.out.println();
			
		}
		String s2=new String ("hello java");
		
		System.out.println(s);
		//case of equal remains of case also
		if (s.equals(s2)) {
			System.out.println("Validated");
		}
		else {
			System.out.println("not valid");
		}
		
		//case of equal 
		if (s.equalsIgnoreCase(s2)) {
			System.out.println("Validated");
			
		}
		else {
			System.out.println("not valid");
		}
		
			
		
		
		
	}

}
