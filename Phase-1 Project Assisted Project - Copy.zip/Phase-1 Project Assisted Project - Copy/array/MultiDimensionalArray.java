package array;

public class MultiDimensionalArray {

	public static void main(String[] args) {
		
		int array[][]= {{1,2,3},{4,5,6},{7,8,9}};
		System.out.println("Length of an array:" +array.length);
		System.out.println("Access first row first element:"+array[0][0]);
		System.out.println("Access second row first element:"+array[1][1]);
		System.out.println("Access third row third element:"+array[2][2]);
		
		for( int row=0; row<array.length;row++) {
			
			for ( int col=0; col<array.length; col++) {
				System.out.print(array[row][col]+"\t");
			}
		}
		

	}

}
